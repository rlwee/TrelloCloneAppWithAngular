from django.apps import AppConfig


class TrelloappConfig(AppConfig):
    name = 'trelloapp'
