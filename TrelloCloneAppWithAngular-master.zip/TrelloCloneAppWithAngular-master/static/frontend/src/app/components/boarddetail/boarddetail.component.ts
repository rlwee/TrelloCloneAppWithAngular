import { Component, OnInit, Inject, Input } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { BoarddetailService } from '../../services/boarddetail/boarddetail.service';
import { Board } from '../../models/boards';
import { BoardlistService } from '../../services/boardlist/boardlist.service';

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { List } from  '../../models/lists'


@Component({
  selector: 'app-boarddetail',
  templateUrl: './boarddetail.component.html',
  styleUrls: ['./boarddetail.component.css']
})

export class BoarddetailComponent implements OnInit {
  boards:Board[] = [];
  board:Board[]
  lists:List; 

  form: FormGroup = new FormGroup({
    listName: new FormControl('',Validators.required)
  });

  constructor(private blist:BoardlistService, private boardDetail:BoarddetailService, private route:Router, private r:ActivatedRoute) { }

  ngOnInit() {
    console.log(this.route.url, 'tetstsest url')
    let board_id = + this.r.snapshot.paramMap.get('id');
    console.log(board_id)
    this.boardDetail.boardDetail(board_id).subscribe( data => {
      this.boards = data;
      console.log(this.boards, 'nice one')
       })
    

    this.blist.displayLists(board_id).subscribe( data => {
      console.log(data)
      this.lists = data;
      // this.lists = data;
    })
    }

    createList():void{
      if(this.form.valid){
        this.boardDetail.createList(this.form.value.listName, this.boards).subscribe( 
        data => {
          let currentUrl = this.route.url
          this.route.navigate([currentUrl + '/lists']);
        console.log(data,' list data test')

      });
      }
    }



  }

   


