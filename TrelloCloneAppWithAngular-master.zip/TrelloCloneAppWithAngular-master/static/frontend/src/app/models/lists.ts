export class List{
    id:number;
    title:string;
    date_created:Date;
    board:string;
    archive:boolean;
}