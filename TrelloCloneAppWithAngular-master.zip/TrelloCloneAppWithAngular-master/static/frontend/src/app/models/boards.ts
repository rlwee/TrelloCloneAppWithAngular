export class Board{
    id:number;
    title:string;
    date_created:Date;
    owner:string;
    archived:boolean;
}